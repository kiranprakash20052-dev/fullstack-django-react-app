from django.contrib import admin
from .models import League, Team, Match
admin.site.register(Team)
admin.site.register(Match)
admin.site.register(League)




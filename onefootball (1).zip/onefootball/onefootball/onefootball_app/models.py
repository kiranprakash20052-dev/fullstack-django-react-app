from django.db import models

# -------------------
# League
# -------------------
class League(models.Model):
    name = models.CharField(max_length=100)
    nation = models.CharField(max_length=50, blank=True)

    def __str__(self):
        return self.name


# -------------------
# Team
# -------------------
# models.py
class Team(models.Model):
    league = models.ForeignKey("League", on_delete=models.CASCADE, related_name="teams")
    name = models.CharField(max_length=100)
    played = models.IntegerField(default=0)
    wins = models.IntegerField(default=0)
    draws = models.IntegerField(default=0)
    losses = models.IntegerField(default=0)
    goals_for = models.IntegerField(default=0)
    goals_against = models.IntegerField(default=0)
    goal_difference = models.IntegerField(default=0)
    points = models.IntegerField(default=0)

    def save(self, *args, **kwargs):
        # Calculate stats automatically
        self.played = self.wins + self.draws + self.losses
        self.goal_difference = self.goals_for - self.goals_against
        self.points = self.wins * 3 + self.draws
        super().save(*args, **kwargs)





# -------------------
# Match
# -------------------
class Match(models.Model):
    league = models.ForeignKey(League, on_delete=models.CASCADE)
    date = models.DateTimeField()
    home_team = models.ForeignKey(Team, on_delete=models.CASCADE, related_name='home_matches')
    away_team = models.ForeignKey(Team, on_delete=models.CASCADE, related_name='away_matches')
    home_score = models.IntegerField(default=0)
    away_score = models.IntegerField(default=0)
    venue = models.CharField(max_length=100, blank=True)

    def __str__(self):
        return f"{self.home_team} vs {self.away_team}"


# -------------------
# MatchStat
# -------------------
class MatchStat(models.Model):
    match = models.OneToOneField(Match, related_name='stats', on_delete=models.CASCADE)
    possession_home = models.IntegerField()
    possession_away = models.IntegerField()
    shots_home = models.IntegerField()
    shots_away = models.IntegerField()

    def __str__(self):
        return f"Stats for {self.match}"


# -------------------
# Standing
# -------------------
class Standing(models.Model):
    league = models.ForeignKey(League, on_delete=models.CASCADE, related_name="standings")
    team = models.ForeignKey(Team, on_delete=models.CASCADE)
    played = models.IntegerField(default=0)
    wins = models.IntegerField(default=0)
    draws = models.IntegerField(default=0)
    losses = models.IntegerField(default=0)
    goals_for = models.IntegerField(default=0)
    goals_against = models.IntegerField(default=0)
    goal_difference = models.IntegerField(default=0)
    points = models.IntegerField(default=0)

    class Meta:
        unique_together = ("league", "team")
        ordering = ["-points", "-goal_difference"]

    def __str__(self):
        return f"{self.team.name} ({self.league.name})"

from rest_framework import serializers
from .models import League, Team, Match, MatchStat, Standing

# -------------------
# League Serializer
# -------------------
class LeagueSerializer(serializers.ModelSerializer):
    teams = serializers.SerializerMethodField()

    class Meta:
        model = League
        fields = ["id", "name", "nation", "teams"]

    def get_teams(self, obj):
        return [{"id": t.id, "name": t.name} for t in obj.teams.all()]

# -------------------
# Team Serializer
# -------------------
class TeamSerializer(serializers.ModelSerializer):
    class Meta:
        model = Team
        fields = "__all__"

# -------------------
# Match Serializer
# -------------------
class MatchSerializer(serializers.ModelSerializer):
    match_date = serializers.DateTimeField(source="date")

    class Meta:
        model = Match
        fields = [
            "id", "home_team", "away_team",
            "home_score", "away_score", "match_date",
            "venue", "league"
        ]

# -------------------
# Match Detail Serializer
# -------------------
class MatchDetailSerializer(serializers.ModelSerializer):
    stats = serializers.SerializerMethodField()

    class Meta:
        model = Match
        fields = [
            "id", "league", "date", "home_team", "away_team",
            "home_score", "away_score", "stats"
        ]

    def get_stats(self, obj):
        if hasattr(obj, "stats"):
            return {
                "possession_home": obj.stats.possession_home,
                "possession_away": obj.stats.possession_away,
                "shots_home": obj.stats.shots_home,
                "shots_away": obj.stats.shots_away
            }
        return None

# -------------------
# Standing Serializer
# -------------------
class StandingSerializer(serializers.ModelSerializer):
    team = serializers.CharField(source="team.name")
    league = serializers.CharField(source="league.name")

    class Meta:
        model = Standing
        fields = [
            "id", "league", "team",
            "played", "wins", "draws", "losses",
            "goals_for", "goals_against",
            "goal_difference", "points"
        ]

# signals.py
from django.db.models.signals import post_save
from django.dispatch import receiver
from .models import Team, Standing

@receiver(post_save, sender=Team)
def create_standing_for_team(sender, instance, created, **kwargs):
    if created:
        # create a Standing row with the team's current stats
        Standing.objects.create(
            league=instance.league,
            team=instance,
            played=instance.played,
            wins=instance.wins,
            draws=instance.draws,
            losses=instance.losses,
            goals_for=instance.goals_for,
            goals_against=instance.goals_against,
            goal_difference=instance.goal_difference,
            points=instance.points,
        )

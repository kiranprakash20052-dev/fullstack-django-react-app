# apps.py
from django.apps import AppConfig

class OnefootballAppConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "onefootball_app"

    def ready(self):
        import onefootball_app.signals

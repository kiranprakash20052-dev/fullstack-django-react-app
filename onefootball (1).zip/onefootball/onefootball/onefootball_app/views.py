from rest_framework.decorators import api_view
from rest_framework.response import Response
from .models import League, Team, Match, Standing
from .serializers import LeagueSerializer, TeamSerializer, MatchSerializer, MatchDetailSerializer, StandingSerializer
from django.shortcuts import get_object_or_404
from rest_framework import status

# -------------------
# Leagues
# -------------------
@api_view(["GET"])
def leagues_view(request):
    leagues = League.objects.prefetch_related("teams").all()
    serializer = LeagueSerializer(leagues, many=True)
    return Response(serializer.data)

# -------------------
# Standings
# -------------------
@api_view(["GET"])
def standings_by_league(request, league_id):
    standings = Standing.objects.filter(league_id=league_id).select_related("team").order_by("-points", "-goal_difference")
    serializer = StandingSerializer(standings, many=True)
    return Response(serializer.data)

# -------------------
# Matches
# -------------------
@api_view(["GET"])
def matches_list(request):
    matches = Match.objects.select_related("league").order_by("date")
    serializer = MatchSerializer(matches, many=True)
    return Response(serializer.data)

@api_view(["GET"])
def match_detail(request, pk):
    match = get_object_or_404(Match.objects.select_related("league"), pk=pk)
    serializer = MatchDetailSerializer(match)
    return Response(serializer.data)

# -------------------
# Team detail
# -------------------
@api_view(["GET"])
def team_detail_view(request, id):
    team = get_object_or_404(Team, id=id)
    serializer = TeamSerializer(team)
    return Response(serializer.data)

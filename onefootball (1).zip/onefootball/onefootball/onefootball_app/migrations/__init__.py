default_app_config = "onefootball_app.apps.FootballConfig"

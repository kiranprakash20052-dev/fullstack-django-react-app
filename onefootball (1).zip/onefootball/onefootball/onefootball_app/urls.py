from django.urls import path
from . import views

urlpatterns = [
    path("leagues/", views.leagues_view, name="leagues"),
    path("standings/<int:league_id>/", views.standings_by_league, name="standings_by_league"),
    path("matches/", views.matches_list, name="matches"),
    path("matches/<int:pk>/", views.match_detail, name="match_detail"),
    path("teams/<int:id>/", views.team_detail_view, name="team_detail"),
]

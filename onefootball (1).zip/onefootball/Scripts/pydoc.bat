python.exe -m pydoc %*

export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        bg: "#0e0f13",
        card: "#15161c",
        accent: "#00ff85",
        muted: "#9ca3af",
      },
    },
  },
  plugins: [],
}

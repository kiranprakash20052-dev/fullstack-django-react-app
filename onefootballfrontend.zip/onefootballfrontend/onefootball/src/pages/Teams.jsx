import { useEffect, useState } from "react";
import api from "../api/axios";
import Navbar from "../components/Navbar";
import TeamCard from "../components/TeamCard";

export default function Teams() {
  const [teams, setTeams] = useState([]);

  useEffect(() => {
    api.get("/teams/").then(res => setTeams(res.data));
  }, []);

  return (
    <>
      <Navbar />
      <div className="p-6 grid grid-cols-4 gap-4">
        {teams.map(t => <TeamCard key={t.id} team={t} />)}
      </div>
    </>
  );
}

import { useEffect, useState } from "react"
import { useParams, Link } from "react-router-dom"
import axios from "../api/axios"
import LeagueHeader from "../components/LeagueHeader"

export default function LeagueTeams() {
  const { id } = useParams()
  const [league, setLeague] = useState(null)
  const [teams, setTeams] = useState([])

  useEffect(() => {
    axios.get(`/leagues/${id}/`).then(res => setLeague(res.data))
    axios.get(`/leagues/${id}/teams/`).then(res => setTeams(res.data))
  }, [id])

  if (!league) return null

  return (
    <div className="pb-20">
      <LeagueHeader league={league} />

      <div className="px-4 mt-4 grid grid-cols-2 gap-3">
        {teams.map(team => (
          <Link
            key={team.id}
            to={`/teams/${team.id}`}
            className="bg-[#111827] border border-[#1f2937] rounded-xl px-3 py-4 hover:bg-[#1f2937]"
          >
            <p className="font-medium truncate">{team.name}</p>
            <p className="text-xs text-gray-400 mt-1">
              {team.city || "—"}
            </p>
          </Link>
        ))}
      </div>
    </div>
  )
}

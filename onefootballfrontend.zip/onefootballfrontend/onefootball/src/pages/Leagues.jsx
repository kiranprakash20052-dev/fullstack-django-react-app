import { useEffect, useState } from "react"
import { Link } from "react-router-dom"
import axios from "../api/axios"

export default function Leagues() {
  const [leagues, setLeagues] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    axios.get("/leagues/")
      .then(res => {
        setLeagues(res.data)
        setLoading(false)
      })
      .catch(() => setLoading(false))
  }, [])

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0f172a] text-white flex items-center justify-center">
        Loading leagues...
      </div>
    )
  }

  if (!leagues.length) {
    return (
      <div className="min-h-screen bg-[#0f172a] text-white flex items-center justify-center">
        No leagues available
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-[#0f172a] text-white px-4 pb-20">
      {/* Header */}
      <div className="sticky top-0 bg-[#0f172a] z-10 py-4">
        <h1 className="text-2xl font-bold">Leagues</h1>
        <p className="text-gray-400 text-sm">Top football competitions</p>
      </div>

      {/* League list */}
      <div className="mt-4 space-y-3">
        {leagues.map(league => (
          <div
            key={league.id}
            className="bg-[#111827] hover:bg-[#1f2933] transition rounded-xl px-4 py-4 border border-[#1f2937]"
          >
            {/* Link to league-specific page */}
            <Link
              to={`/leagues/${league.id}`}
              className="flex items-center justify-between"
            >
              <div>
                <h2 className="font-semibold text-lg">{league.name}</h2>
                <p className="text-gray-400 text-sm">{league.nation}</p>
              </div>
              <span className="text-gray-500 text-xl">›</span>
            </Link>

            {/* Show teams inside league */}
            {league.teams && league.teams.length > 0 && (
              <ul className="mt-2 ml-2 list-disc list-inside text-gray-300">
                {league.teams.map(team => (
                  <li key={team.id}>{team.name}</li>
                ))}
              </ul>
            )}
          </div>
        ))}
      </div>
    </div>
  )
}

import api from '../api'

export default function Login() {
  const handleLogin = () => {
    api.post('login/', { username: 'admin', password: 'admin' })
      .then(() => window.location.href = '/dashboard')
  }

  return (
    <div className="page">
      <h2>Login</h2>
      <button onClick={handleLogin}>Login</button>
    </div>
  )
}

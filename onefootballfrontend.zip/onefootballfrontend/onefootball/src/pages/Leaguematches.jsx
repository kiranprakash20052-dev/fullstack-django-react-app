import { useEffect, useState } from "react"
import { useParams } from "react-router-dom"
import axios from "../api/axios"
import LeagueHeader from "../components/LeagueHeader"
import MatchCard from "../components/MatchCard"

export default function LeagueMatches() {
  const { id } = useParams()
  const [league, setLeague] = useState(null)
  const [matches, setMatches] = useState([])

  useEffect(() => {
    axios.get(`/leagues/${id}/`).then(res => setLeague(res.data))
    axios.get(`/leagues/${id}/matches/`).then(res => setMatches(res.data))
  }, [id])

  if (!league) return null

  return (
    <div className="pb-20">
      <LeagueHeader league={league} />

      <div className="px-4 mt-4 space-y-3">
        {matches.map(match => (
          <MatchCard key={match.id} match={match} />
        ))}
      </div>
    </div>
  )
}

import { useEffect, useState } from "react";
import axios from "../api/axios";
import MatchCard from "../components/MatchCard";
import StatCard from "../components/StatCard";

export default function Home() {
  const [matches, setMatches] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    axios
      .get("/matches/")
      .then((res) => {
        setMatches(Array.isArray(res.data) ? res.data : []);
      })
      .catch((err) => console.error(err))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="px-4 pb-20 bg-black min-h-screen">
      {/* Header */}
      <div className="pt-4 pb-3">
        <h1 className="text-2xl font-bold text-white">Football</h1>
        <p className="text-gray-400 text-sm">
          Today’s matches & highlights
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3 mb-6">
        <StatCard label="Matches" value={matches.length} />
        <StatCard
          label="Live"
          value={matches.filter((m) => m.status === "LIVE").length}
        />
        <StatCard
          label="Finished"
          value={matches.filter((m) => m.status === "FT").length}
        />
      </div>

      {/* Matches */}
      <div className="space-y-3">
        {loading && (
          <p className="text-center text-gray-500 mt-6">Loading matches…</p>
        )}

        {!loading && matches.length === 0 && (
          <p className="text-center text-gray-500 mt-6">No matches today</p>
        )}

        {!loading &&
          matches.map((match) => (
            <MatchCard key={match.id} match={match} />
          ))}
      </div>
    </div>
  );
}

import { useEffect, useState } from "react"
import axios from "../api/axios"
import MatchCard from "../components/MatchCard"

export default function Dashboard() {
  const [matches, setMatches] = useState([])

  useEffect(() => {
    axios.get("/matches/").then(res => setMatches(res.data))
  }, [])

  return (
    <div className="px-4 pb-20">
      <h1 className="text-2xl font-bold mt-4">
        Matches
      </h1>

      <div className="mt-4 space-y-3">
        {matches.slice(0, 10).map(match => (
          <MatchCard key={match.id} match={match} />
        ))}
      </div>
    </div>
  )
}

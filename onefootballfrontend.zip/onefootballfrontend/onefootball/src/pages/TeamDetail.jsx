import { useParams } from 'react-router-dom'
import { useEffect, useState } from 'react'
import api from '../api'

export default function TeamDetails() {
  const { id } = useParams()
  const [team, setTeam] = useState(null)

  useEffect(() => {
    api.get(`teams/${id}/`).then(res => setTeam(res.data))
  }, [id])

  if (!team) return null

  return (
    <div className="page">
      <h2>{team.name}</h2>
      <p>Points: {team.points}</p>
      <p>Played: {team.played}</p>
    </div>
  )
}

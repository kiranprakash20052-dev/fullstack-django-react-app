import { useEffect, useState } from "react"
import { useParams } from "react-router-dom"
import axios from "../api/axios"

export default function MatchDetail() {
  const { id } = useParams()
  const [match, setMatch] = useState(null)

  useEffect(() => {
    axios.get(`/matches/${id}/`)
      .then(res => setMatch(res.data))
  }, [id])

  if (!match) {
    return <p className="text-center text-gray-400 mt-10">Loading...</p>
  }

  const s = match.stats

  return (
    <div className="px-4 pb-20">
      {/* SCORE */}
      <div className="text-center my-6">
        <h2 className="text-lg font-semibold">
          {match.home_team_name} vs {match.away_team_name}
        </h2>
        <p className="text-3xl font-bold mt-2">
          {match.home_score} - {match.away_score}
        </p>
      </div>

      {/* STATS */}
      {s && (
        <div className="bg-[#020617] border border-[#1f2937] rounded-xl p-4">
          <StatRow label="Possession" home={s.possession_home + "%"} away={s.possession_away + "%"} />
          <StatRow label="Shots" home={s.shots_home} away={s.shots_away} />
          <StatRow label="Shots on Target" home={s.shots_on_target_home} away={s.shots_on_target_away} />
          <StatRow label="Fouls" home={s.fouls_home} away={s.fouls_away} />
        </div>
      )}
    </div>
  )
}

function StatRow({ label, home, away }) {
  return (
    <div className="flex justify-between text-sm py-2 border-b border-[#1f2937]">
      <span className="w-12 text-left">{home}</span>
      <span className="text-gray-400">{label}</span>
      <span className="w-12 text-right">{away}</span>
    </div>
  )
}

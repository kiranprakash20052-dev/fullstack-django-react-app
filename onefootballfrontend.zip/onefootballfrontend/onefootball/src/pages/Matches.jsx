import { useEffect, useState } from "react"
import axios from "../api/axios"
import { useNavigate } from "react-router-dom"

export default function Matches() {
  const [matches, setMatches] = useState([])
  const [loading, setLoading] = useState(true)
  const navigate = useNavigate()

  useEffect(() => {
    axios.get("/matches/")
      .then(res => {
        setMatches(Array.isArray(res.data) ? res.data : [])
      })
      .finally(() => setLoading(false))
  }, [])

  return (
    <div className="px-4 pb-20 bg-black min-h-screen">
      {/* Page Header */}
      <div className="sticky top-0 bg-black z-10 py-4">
        <h1 className="text-xl font-bold text-white">
          Matches
        </h1>
        <p className="text-sm text-gray-400">
          Today & recent fixtures
        </p>
      </div>

      {/* Loading */}
      {loading && (
        <p className="text-center text-gray-400 mt-10">
          Loading matches…
        </p>
      )}

      {/* Empty */}
      {!loading && matches.length === 0 && (
        <p className="text-center text-gray-400 mt-10">
          No matches available
        </p>
      )}

      {/* Match List */}
      <div className="space-y-3 mt-4">
        {matches.map(match => (
          <div
            key={match.id}
            onClick={() => navigate(`/matches/${match.id}`)}
            className="bg-[#020617] border border-[#1f2937] rounded-2xl px-4 py-4 cursor-pointer hover:border-gray-500 transition"
          >
            {/* Top Row */}
            <div className="flex justify-between items-center text-xs text-gray-400 mb-3">
              <span>
                {match.league_name || "League"}
              </span>
              <span>
                {new Date(match.match_date).toLocaleDateString()}
              </span>
            </div>

            {/* Teams & Score */}
            <div className="flex items-center justify-between text-white">
              <div className="flex-1 truncate text-sm font-medium">
                {match.home_team_name}
              </div>

              <div className="px-3 text-lg font-bold">
                {match.home_score} – {match.away_score}
              </div>

              <div className="flex-1 truncate text-sm font-medium text-right">
                {match.away_team_name}
              </div>
            </div>

            {/* Status */}
            <div className="text-center text-xs text-gray-500 mt-3">
              {match.status || "FT"}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

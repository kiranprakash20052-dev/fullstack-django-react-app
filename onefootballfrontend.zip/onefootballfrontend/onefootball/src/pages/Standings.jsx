import { useEffect, useState } from "react"
import { useParams, Link } from "react-router-dom"
import axios from "../api/axios"

export default function Standings() {
  const { leagueId } = useParams()

  const [standings, setStandings] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    if (!leagueId) return

    setLoading(true)
    setError(null)

    axios
      .get(`/standings/${leagueId}/`)
      .then(res => {
        const data = Array.isArray(res.data) ? res.data : []

        // ✅ DO NOT MUTATE ORIGINAL ARRAY
        const sorted = [...data].sort((a, b) => {
          if ((b.points ?? 0) !== (a.points ?? 0)) {
            return (b.points ?? 0) - (a.points ?? 0)
          }
          return (b.goal_difference ?? 0) - (a.goal_difference ?? 0)
        })

        setStandings(sorted)
        setLoading(false)
      })
      .catch(err => {
        console.error("Standings error:", err)
        setError("Failed to load standings")
        setStandings([])
        setLoading(false)
      })
  }, [leagueId])

  /* -------------------- STATES -------------------- */

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center text-white">
        Loading standings...
      </div>
    )
  }

  if (error) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center text-red-400">
        {error}
        <Link to="/leagues" className="mt-2 text-blue-400 underline">
          Back to leagues
        </Link>
      </div>
    )
  }

  if (!standings.length) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center text-gray-400">
        No standings available
        <Link to="/leagues" className="mt-2 text-blue-400 underline">
          Back to leagues
        </Link>
      </div>
    )
  }

  /* -------------------- TABLE -------------------- */

  return (
    <div className="px-4 pb-20 text-white">
      <div className="flex items-center justify-between mt-4 mb-3">
        <h1 className="text-xl font-bold">Standings</h1>
        <Link to="/leagues" className="text-sm text-blue-400">
          ← Leagues
        </Link>
      </div>

      <div className="bg-[#020617] border border-[#1f2937] rounded-xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center text-xs text-gray-400 px-3 py-2 border-b border-[#1f2937]">
          <span className="w-6">#</span>
          <span className="flex-1">Team</span>
          <span className="w-8 text-right">P</span>
          <span className="w-8 text-right">W</span>
          <span className="w-8 text-right">D</span>
          <span className="w-8 text-right">L</span>
          <span className="w-10 text-right">GF</span>
          <span className="w-10 text-right">GA</span>
          <span className="w-10 text-right">GD</span>
          <span className="w-8 text-right">Pts</span>
        </div>

        {/* Rows */}
        {standings.map((row, index) => {
          const indicator =
            index < 4
              ? "bg-green-500"
              : index >= standings.length - 3
              ? "bg-red-500"
              : "bg-transparent"

          return (
            <div
              key={row.id ?? `${row.team?.id}-${index}`}
              className="flex items-center text-sm px-3 py-2 border-b border-[#1f2937] hover:bg-[#020617]/80"
            >
              <span className={`w-1 h-6 mr-2 rounded ${indicator}`} />
              <span className="w-6 text-gray-400">{index + 1}</span>
              <span className="flex-1 truncate font-medium">
                {row.team?.name || "Unknown"}
              </span>
              <span className="w-8 text-right">{row.played ?? 0}</span>
              <span className="w-8 text-right">{row.wins ?? 0}</span>
              <span className="w-8 text-right">{row.draws ?? 0}</span>
              <span className="w-8 text-right">{row.losses ?? 0}</span>
              <span className="w-10 text-right">{row.goals_for ?? 0}</span>
              <span className="w-10 text-right">{row.goals_against ?? 0}</span>
              <span className="w-10 text-right">{row.goal_difference ?? 0}</span>
              <span className="w-8 text-right font-semibold">
                {row.points ?? 0}
              </span>
            </div>
          )
        })}
      </div>

      {/* Legend */}
      <div className="flex gap-4 text-xs text-gray-400 mt-3">
        <div className="flex items-center gap-1">
          <span className="w-2 h-2 bg-green-500 rounded" />
          Champions League
        </div>
        <div className="flex items-center gap-1">
          <span className="w-2 h-2 bg-red-500 rounded" />
          Relegation
        </div>
      </div>
    </div>
  )
}

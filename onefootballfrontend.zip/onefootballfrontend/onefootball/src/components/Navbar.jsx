import { Link, useLocation } from "react-router-dom"

export default function Navbar() {
  const { pathname } = useLocation()

  const link = path =>
    `px-3 py-1 rounded-full ${
      pathname === path ? "bg-accent text-black" : "text-muted"
    }`

  return (
    <nav className="flex items-center gap-3 px-5 py-3 border-b border-zinc-800 bg-card sticky top-0 z-50">
      <h1 className="font-bold text-accent mr-auto">OneFootball</h1>
      <Link to="/" className={link("/")}>Home</Link>
      <Link to="/leagues" className={link("/leagues")}>Leagues</Link>
      <Link to="/matches" className={link("/matches")}>Matches</Link>
    </nav>
  )
}

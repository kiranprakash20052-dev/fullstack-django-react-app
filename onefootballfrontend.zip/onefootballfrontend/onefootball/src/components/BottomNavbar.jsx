import { NavLink } from "react-router-dom"

export default function BottomNavbar() {
  const linkClass = ({ isActive }) =>
    `text-xs font-medium ${
      isActive ? "text-white" : "text-gray-400"
    }`

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-[#020617] border-t border-[#1f2937] h-14 flex justify-around items-center z-50">
      
      <NavLink to="/" className={linkClass}>
        Home
      </NavLink>

      <NavLink to="/leagues" className={linkClass}>
        Leagues
      </NavLink>

      <NavLink to="/matches" className={linkClass}>
        Matches
      </NavLink>

      <NavLink to="/standings" className={linkClass}>
        Table
      </NavLink>

      <NavLink to="/login" className={linkClass}>
        Profile
      </NavLink>
    </nav>
  )
}

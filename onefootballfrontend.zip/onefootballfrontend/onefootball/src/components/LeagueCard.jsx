import { Link } from "react-router-dom"

export default function LeagueCard({ league }) {
  return (
    <Link
      to={`/leagues/${league.id}`}
      className="bg-card rounded-xl p-4 flex justify-between items-center border border-zinc-800 hover:bg-zinc-800 transition"
    >
      <div>
        <h3 className="text-lg font-semibold">{league.name}</h3>
        <p className="text-muted text-sm">{league.country}</p>
      </div>
      <span className="text-accent text-xl">›</span>
    </Link>
  )
}

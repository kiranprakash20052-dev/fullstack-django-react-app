import { Link } from "react-router-dom"

export default function TeamCard({ team }) {
  return (
    <Link
      to={`/teams/${team.id}`}
      className="bg-card rounded-xl p-4 flex items-center gap-4 border border-zinc-800 hover:bg-zinc-800 transition"
    >
      <img
        src={team.logo}
        alt={team.name}
        className="w-10 h-10 object-contain"
      />
      <div className="flex-1">
        <h4 className="font-semibold">{team.name}</h4>
        <p className="text-muted text-sm">{team.points} pts</p>
      </div>
      <span className="text-muted">›</span>
    </Link>
  )
}

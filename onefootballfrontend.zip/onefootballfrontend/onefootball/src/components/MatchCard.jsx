import { Link } from "react-router-dom";

export default function MatchCard({ match }) {
  return (
    <Link
      to={`/matches/${match.id}`}
      className="block bg-[#020617] hover:bg-[#020617]/80 transition rounded-xl border border-[#1f2937] px-4 py-3"
    >
      {/* League / Status */}
      <div className="flex justify-between items-center mb-2">
        <span className="text-xs text-gray-400 truncate">
          {match.league_name || "League"}
        </span>
        <span className="text-xs text-green-400 font-medium">
          FT
        </span>
      </div>

      {/* Teams + Score */}
      <div className="space-y-2">
        {/* Home team */}
        <div className="flex justify-between items-center">
          <p className="text-sm font-medium truncate">
            {match.home_team}
          </p>
          <span className="text-sm font-semibold">
            {match.home_score}
          </span>
        </div>

        {/* Away team */}
        <div className="flex justify-between items-center">
          <p className="text-sm font-medium truncate">
            {match.away_team}
          </p>
          <span className="text-sm font-semibold">
            {match.away_score}
          </span>
        </div>
      </div>

      {/* Date */}
      <p className="text-xs text-gray-400 text-center mt-3">
        {match.date
          ? new Date(match.date).toLocaleString()
          : "Date TBD"}
      </p>
    </Link>
  );
}

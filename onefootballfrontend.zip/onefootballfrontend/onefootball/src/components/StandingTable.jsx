export default function StandingTable({ standings }) {
  return (
    <table className="w-full bg-white rounded shadow">
      <thead>
        <tr className="border-b text-left">
          <th className="p-2">Team</th>
          <th className="p-2">P</th>
          <th className="p-2">W</th>
          <th className="p-2">D</th>
          <th className="p-2">L</th>
          <th className="p-2">Pts</th>
        </tr>
      </thead>
      <tbody>
        {standings.map((s, i) => (
          <tr key={i} className="border-b hover:bg-gray-50">
            <td className="p-2 font-medium">{s.team}</td>
            <td className="p-2">{s.played}</td>
            <td className="p-2">{s.wins}</td>
            <td className="p-2">{s.draw}</td>
            <td className="p-2">{s.losses}</td>
            <td className="p-2 font-bold">{s.points}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

import { Link } from "react-router-dom"

export default function LeagueHeader({ league }) {
  return (
    <div className="bg-gradient-to-b from-[#020617] to-[#0f172a] px-4 pt-5 pb-4 border-b border-[#1f2937]">
      
      <Link
        to="/leagues"
        className="text-gray-400 text-sm hover:text-white"
      >
        ← Leagues
      </Link>

      <h1 className="text-2xl font-bold mt-2">
        {league.name}
      </h1>

      <p className="text-gray-400 text-sm">
        {league.country}
      </p>

      {/* Tabs */}
      <div className="flex gap-6 mt-4 text-sm font-medium">
        <span className="text-white border-b-2 border-white pb-1">
          Teams
        </span>
        <span className="text-gray-400">Matches</span>
        <span className="text-gray-400">Table</span>
      </div>
    </div>
  )
}

export default function StatCard({ label, value }) {
  return (
    <div className="bg-[#020617] border border-[#1f2937] rounded-xl p-3 text-center">
      <p className="text-gray-400 text-xs">
        {label}
      </p>
      <p className="text-white text-lg font-bold">
        {value}
      </p>
    </div>
  )
}

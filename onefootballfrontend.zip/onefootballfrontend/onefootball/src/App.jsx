import { Routes, Route, Navigate } from "react-router-dom"
import Navbar from "./components/Navbar"

import Home from "./pages/Home"
import Login from "./pages/Login"
import Matches from "./pages/Matches"
import MatchDetails from "./pages/MatchDetail"
import TeamDetails from "./pages/TeamDetail"
import Standings from "./pages/Standings"
import Dashboard from "./pages/Dashboard"
import Leagues from "./pages/Leagues"
import BottomNavbar from "./components/BottomNavbar"
import LeagueMatches from "./pages/Leaguematches"

const Protected = ({ children }) =>
  document.cookie.includes("sessionid")
    ? children
    : <Navigate to="/login" />

export default function App() {
  return (
    <>

      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/leagues" element={<Leagues />} />
        <Route path="/matches" element={<Matches />} />
        <Route path="/matches/:id" element={<MatchDetails />} />
        <Route path="/teams/:id" element={<TeamDetails />} />
        <Route path="/leagues/:leagueId" element={<Standings />} />
        <Route path="/leagues/:id/matches" element={<LeagueMatches />} />
        <Route path="/standings" element={<Standings />} />
        <Route path="/bottomnavbar" element={<BottomNavbar />} />
        <Route
          path="/dashboard"
          element={
            <Protected>
              <Dashboard />
            </Protected>
          }
        />
      </Routes>
    </>
  )
}
